<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4 Rivers</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="header">
        <div class="logo">
            <a href="#">YUHUHUHUHU</a>
            <span>|</span>
            <a href="#">MADANG 4U</a>
        </div>
        <div class="menu">
            <?php include 'menu.php'; ?>
        </div>
    </header>

    <main class="main-content">
        <div class="featured-item">
            <h3>WARONG PAUS</h3>
            <p>awowkwowkwowkwowkwo</p>
            <P>berdiri sejak 3 jam yang lalu</p>
            
        </div>
        <div class="few-favorites">
            <h2>MENU</h2>
            <div class="menu-item">
                <h3> NASI GANDUL</h3>
                <p>RP 5.000</p>
            </div>
            <div class="menu-item">
                <h3>NASI RAMES</h3>
                <p>RP 5000.</p>
            </div>
            <div class="menu-item">
                <h3>NASI LALAPAN</h3>
                <p>RP 20.000.</p>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="footer-content">
            <!-- Add your footer content here -->
        </div>
    </footer>

</body>
</html>