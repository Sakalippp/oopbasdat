<?php

// Definisikan kelas Makanan
class Makanan {
    private $nama;
    private $harga;

    // Konstruktor untuk inisialisasi objek Makanan
    public function __construct($nama, $harga) {
        $this->nama = $nama;
        $this->harga = $harga;
    }

    // Getter untuk mendapatkan nama makanan
    public function getNama() {
        return $this->nama;
    }

    // Getter untuk mendapatkan harga makanan
    public function getHarga() {
        return $this->harga;
    }
}

// Buat kelas turunan MakananLengkap yang mewarisi dari Makanan
class MakananLengkap extends Makanan {
    private $keterangan;

    // Konstruktor untuk inisialisasi objek MakananLengkap
    public function __construct($nama, $harga, $keterangan) {
        // Panggil konstruktor dari kelas induk (Makanan)
        parent::__construct($nama, $harga);

        $this->keterangan = $keterangan;
    }

    // Getter untuk mendapatkan keterangan makanan
    public function getKeterangan() {
        return $this->keterangan;
    }
}


