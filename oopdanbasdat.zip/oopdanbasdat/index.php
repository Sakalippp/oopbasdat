<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NDANG MANGAN </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        
    </header>

    <div class="container">
    <div class="header-container">
            <h1>Madang Slebeww</h1>
            <p>Mangan dulu baru bayar</p>
        </div>
        <h1>Data Makanan</h1>

        <?php
        // Definisikan kelas Makanan dan MakananLengkap (seperti sebelumnya)
        require_once('makanan.php');

        // Contoh penggunaan kelas MakananLengkap dengan 4 buah makanan
        $makanan1 = new MakananLengkap("Nasi Uap", 15000.0, "Lezat dan pedas");
        $makanan2 = new MakananLengkap("Mie Tongseng", 12000.0, "Enak dan lumer");
        $makanan3 = new MakananLengkap("Sate Kelinci", 20000.0, "Gurih dan nikmat");
        $makanan4 = new MakananLengkap("Bakso Tanpa Tepung", 18000.0, "Empuk dan Bergiji");
        ?>

        <div class="makanan">
            <h2>Makanan 1</h2>
            <p><strong>Nama:</strong> <?php echo $makanan1->getNama(); ?></p>
            <p><strong>Harga:</strong> <?php echo $makanan1->getHarga(); ?></p>
            <p><strong>Keterangan:</strong> <?php echo $makanan1->getKeterangan(); ?></p>
        </div>

        <div class="makanan">
            <h2>Makanan 2</h2>
            <p><strong>Nama:</strong> <?php echo $makanan2->getNama(); ?></p>
            <p><strong>Harga:</strong> <?php echo $makanan2->getHarga(); ?></p>
            <p><strong>Keterangan:</strong> <?php echo $makanan2->getKeterangan(); ?></p>
        </div>

        <div class="makanan">
            <h2>Makanan 3</h2>
            <p><strong>Nama:</strong> <?php echo $makanan3->getNama(); ?></p>
            <p><strong>Harga:</strong> <?php echo $makanan3->getHarga(); ?></p>
            <p><strong>Keterangan:</strong> <?php echo $makanan3->getKeterangan(); ?></p>
        </div>

        <div class="makanan">
            <h2>Makanan 4</h2>
            <p><strong>Nama:</strong> <?php echo $makanan4->getNama(); ?></p>
            <p><strong>Harga:</strong> <?php echo $makanan4->getHarga(); ?></p>
            <p><strong>Keterangan:</strong> <?php echo $makanan4->getKeterangan(); ?></p>
        </div>

    </div>

</body>

</html>
