<a href="http://localhost/oopdanbangsat/index.php#">HOME</a>
<span>|</span>
<a href="http://localhost/oopdanbasdat/index.php">MAKANAN</a>
<span>|</span>
<a href="#">MINUMAN</a>
<span>|</span>
<a href="#">?</a>
<span>|</span>

